public class BandMatrix 
{
	public static void main(String args[]) // Let's make a band-structured matrix
	{
		int n = Integer.parseInt(args[0]); // n x n 
		int width = Integer.parseInt(args[1]); // of band
		
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (i - width <= j && j <= i + width) System.out.print("*  ");
				else System.out.print("0  ");
			}
			System.out.println("");
		}
	}
}

			
		
		